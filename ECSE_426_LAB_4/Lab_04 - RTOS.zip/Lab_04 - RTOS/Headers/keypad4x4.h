#ifndef _KEYPAD_H
#define _KEYPAD_H

void setColumnsAsInput(void);
void setRowsAsInput(void);
int getColumnOfKeyPressed(void);
int getRowOfKeyPressed(void);
int getKeyPressed(void);

#endif
