#ifndef _THREAD_LED_H
#define _THREAD_LED_H

void Thread_1 (void const *argument);
void Thread_2 (void const *argument);

int start_Thread_2 (void);

#endif
